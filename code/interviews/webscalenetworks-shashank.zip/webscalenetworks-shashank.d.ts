declare function mostCommon(numbers: number[]): number;
declare const countMe: number[];
//# sourceMappingURL=webscalenetworks-shashank.d.ts.map